from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm
from .models import *


class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields =  ['username', 'password1', 'password2', 'email']




class UpdateSubscriptionForm(ModelForm):
    class Meta:
        model = Settings
        fields = ['user', 'subscription',]
            
    def __init__(self,  *args, **kwargs):
        super(UpdateSubscriptionForm, self).__init__(*args, **kwargs)
        self.fields['subscription'].queryset = Journal.objects.filter(radiology=True)














class VoteForm(ModelForm):
    class Meta:
        model = Votes
        fields = ['user', 'article', 'upvote', 'downvote']




















class SubscribeForm(ModelForm):
    class Meta:
        model = Settings
        subscription = forms.ModelMultipleChoiceField(queryset=Journal.objects.filter(radiology=True), widget=forms.CheckboxSelectMultiple)
        fields = ['user', 'subscription']

    def __init__(self,  *args, **kwargs):
        super(SubscribeForm, self).__init__(*args, **kwargs)
        self.fields['subscription'].queryset = Journal.objects.filter(radiology=True)



BIRTH_YEAR_CHOICES = ['1980', '1981', '1982']
FAVORITE_COLORS_CHOICES = [
    ('blue', 'Blue'),
    ('green', 'Green'),
    ('black', 'Black'),
]

class testForm(forms.Form):
    birth_year = forms.DateField(widget=forms.SelectDateWidget(years=BIRTH_YEAR_CHOICES))
    favorite_colors = forms.MultipleChoiceField(
        required=False,
        widget=forms.CheckboxSelectMultiple,
        choices=[(i.name, (i.name)) for i in Journal.objects.filter(radiology=True).all()],
    )
   