from django.contrib import admin
from django.urls import path, re_path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    re_path(r'^home', views.feed_view, name='home'),
    path('', views.feed_view, name='new'),
    re_path(r'^logout', views.logout_view, name='logout'),
    re_path(r'^login', views.login_view, name='login'),
    re_path(r'^register', views.register_view, name='register'),
    re_path(r'^reset', views.reset_view, name='reset'),
    re_path(r'^subscriptions', views.subscriptions_view, name='subscriptions'),
    re_path(r'^bookmarks', views.bookmarks_view, name='bookmarks'),
    re_path(r'^dashboard', views.dashboard_view, name='dashboard'),



]
