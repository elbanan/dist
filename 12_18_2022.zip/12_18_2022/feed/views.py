from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
import itertools

from .models import *
from .forms import *
from .core import *
from datetime import date


app_name = "RAD-FLEX"

templates = {

    'home': 'feed/home.html',
    'bookmarks': 'feed/bookmarks.html',
    'login': 'feed/login.html',
    'reset': 'feed/reset.html',
    'register':'feed/register.html',
    'feed':'feed/feed.html',
    'subscriptions':'feed/subscriptions.html',
    'dashboard':'feed/dashboard.html',


    }


#feed
#latest
#bookmarks


freq_map={
    'daily': 1,
    'weekly': 7,
    'biweekly': 14,
    'monthly': 30,
}

# ======================================================================================================== #


# Login/Register Controllers
def unauthenticated_user(view_func):
	def wrapper_func(request, *args, **kwargs):
		if request.user.is_authenticated:
			return redirect('home')
		else:
			return view_func(request, *args, **kwargs)
	return wrapper_func

def allowed_users(allowed_roles=[]):
	def decorator(view_func):
		def wrapper_func(request, *args, **kwargs):

			group = None
			if request.user.groups.exists():
				group = request.user.groups.all()[0].name

			if group in allowed_roles:
				return view_func(request, *args, **kwargs)
			else:
				return redirect('home')
		return wrapper_func
	return decorator

@unauthenticated_user
def register_view(request):
    content = {
    'page_title': 'Create a New User',
    'app_name': app_name,
    }    
    if request.method=="POST":
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            print ("Passwords checked out")
            try:
                user = User.objects.create_user(username=username, password=password1)
                user.save()
                settings = Settings.objects.create(user=user)
                return redirect('login')
            except:
                print ("Username already taken")
                return render(request, templates['register'], content)
        else:
            print ("Passwords did not match")
            return render(request, templates['register'], content)
    else:
        return render(request, templates['register'], content)

@unauthenticated_user 
def login_view(request, *args, **kwargs): 
    content = {
    'page_title': 'Login',
    'app_name': app_name,

    }
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect ('home')
        else:
            return render(request, templates['login'], content)
    else:
        return render(request, templates['login'], content)

@unauthenticated_user 
def reset_view(request, *args, **kwargs): 
    content = {
    'page_title': 'Reset Your Password',
    'app_name': app_name,
    }    
    return render(request, templates['reset'], content)


def logout_view(request, *args, **kwargs):
    logout(request)
    return redirect('/login')



# # ======================================================================================================== #

@login_required(login_url='login')
def feed_view(request):
    today=date.today()
    user_freq = Settings.objects.get(user=request.user).frequency
    date_start, date_end = getDatesFromToday(user_freq)
    date_start, date_end = fix_date(date_start), fix_date(date_end)

    try:
        sub_journals = Settings.objects.get(user=request.user).subscription.all()
        no_articles = False

    except:
        sub_journals = []
        
    if len(sub_journals) > 0:
        no_articles = False
    else:
        no_articles = True

    articles = Article.objects.filter(journal__in=sub_journals).filter(pubdate__range=[date_start, date_end]).order_by('-pubdate')

    if request.method == 'POST':
        if 'bookmarked_article' in request.POST:
            bookmarked_article = int(request.POST.get('bookmarked_article'))
            current_user = request.user
            try:
                update = Settings.objects.get(user=current_user)
            except:
                update = Settings.objects.create(user=current_user)
            update.bookmarks.add(bookmarked_article)
            update.save()
        elif 'upvote_article' in request.POST:
            try:
                vote = Votes.objects.get(user=request.user, article=articles.get(pmid=request.POST.get('upvote_article')))
                if vote.upvote:
                    vote.upvote=False
                else:
                    vote.upvote=True
            except:
                vote = Votes.objects.create(user=request.user, article=articles.get(pmid=request.POST.get('upvote_article')))
                vote.upvote=True
            vote.downvote=False    
            vote.save()
        elif 'downvote_article' in request.POST:
            try:
                vote = Votes.objects.get(user=request.user, article=articles.get(pmid=request.POST.get('downvote_article')))
                if vote.downvote:
                    vote.downvote=False
                else:
                    vote.downvote=True
            except:
                vote = Votes.objects.create(user=request.user, article=articles.get(pmid=request.POST.get('downvote_article')))
                vote.downvote=True
            vote.upvote=False    
            vote.save()

        up_vote_count = []
        down_vote_count = []

        for article in articles:
            try:
                up_vote_count.append(Votes.objects.filter(article=article).filter(upvote=True).count())
                down_vote_count.append(Votes.objects.filter(article=article).filter(downvote=True).count())
            except:
                up_vote_count.append(0)
                down_vote_count.append(0)
                pass
        A = dict(zip(articles, zip(up_vote_count, down_vote_count)))  

        content = {
            'page_title': 'My Feed',
            'articles': articles,
            'no_articles': no_articles,
            'date_start': date_start,
            'date_end': date_end,
            'app_name': app_name,
            'up_vote_count': up_vote_count,
            'down_vote_count': down_vote_count,
            'A': A.items(),
        }
    
        return render(request, templates['feed'], content)    



    up_vote_count = []
    down_vote_count = []

    for article in articles:
        try:
            up_vote_count.append(Votes.objects.filter(article=article).filter(upvote=True).count())
            down_vote_count.append(Votes.objects.filter(article=article).filter(downvote=True).count())
        except:
            up_vote_count.append(0)
            down_vote_count.append(0)
            pass

    A = dict(zip(articles, zip(up_vote_count, down_vote_count)))   

    
    content = {
        'page_title': 'My Feed',
        'articles': articles,
        'no_articles': no_articles,
        'date_start': date_start,
        'date_end': date_end,
        'app_name': app_name,
        'up_vote_count': up_vote_count,
        'down_vote_count': down_vote_count,
        'A': A.items(),
    }


    return render(request, templates['feed'], content)





@login_required(login_url='login')
def latest_view(request):
    articles= Article.objects.all()

    if request.method == 'POST':
        bookmarked_article = int(request.POST.get('bookmarked_article'))
        current_user = request.user
        try:
            update = Settings.objects.get(user=current_user)
        except:
            update = Settings.objects.create(user=current_user)
        update.bookmarks.add(bookmarked_article)
        update.save()


    content = {
        'page_title': 'RAD tl;dr',
        'articles': articles,
        'app_name': app_name,



    }    
    return render(request, templates['home'], content)







@login_required(login_url='login')
def bookmarks_view(request):
    try:
        articles = Settings.objects.get(user=request.user).bookmarks.all()
    except:
        articles = []

    if request.method == 'POST':
        bookmarked_article = int(request.POST.get('bookmarked_article'))
        current_user = request.user
        try:
            update = Settings.objects.get(user=current_user)
        except:
            update = Settings.objects.create(user=current_user)
        update.bookmarks.remove(bookmarked_article)
        update.save()

    content = {
        'page_title': 'RAD tl;dr - My Bookmarks',
        'articles': articles,
        'app_name': app_name,


    }    
    return render(request, templates['bookmarks'], content)


# # ======================================================================================================== #


@login_required(login_url='login')
def subscriptions_view(request):
    journals =  Journal.objects.filter(radiology=True).order_by('name')
    try:
        current_subscription = Settings.objects.get(user=request.user.id).subscription.all()
    except:
        current_subscription = ["None"]

    try:
        current_freq_int = Settings.objects.get(user=request.user.id).frequency
        current_freq = [k for k, v in freq_map.items() if v == current_freq_int][0]
    except:
        current_freq = "None"
    

    if request.method == 'POST':
        current_user = request.user
        
        selected_journals = request.POST.getlist('selected_journals')
        selected_freq = request.POST.get('selected_freq')

        try:
            update = Settings.objects.get(user=current_user)
        except:
            update = Settings.objects.create(user=current_user)

        update.subscription.set(selected_journals)
        update.frequency = (freq_map[selected_freq])
        update.save()
    else:
        pass     
   
    content = {
        'page_title': 'Subscription Settings',
        'journals': journals,
        'current_subscription': current_subscription,
        'current_freq':  current_freq,
        'frequency':list(freq_map.keys()),
        'app_name': app_name,

    }

    return render(request, templates['subscriptions'], content)


# # ======================================================================================================== #

@login_required(login_url='login')
def dashboard_view(request):

    all_articles_ids = Article.objects.all().values_list('pmid', flat=True)

    journal_subscritions_all = []
    all_settings = Settings.objects.all()
    for i in all_settings:
        if len(i.subscription.all()) > 0:
            journal_subscritions_all.append(i.subscription.all())
    journal_subscritions_all = (list(itertools.chain.from_iterable(journal_subscritions_all)))

    if request.method == 'POST':
        num_days = int(request.POST.get('num_days'))
        update_table = getUpdates([i.name for i in journal_subscritions_all],num_days )
        
        for i, r in update_table.iterrows():
            if int(r['pubmed']) in all_articles_ids:
                print ('JOB: ADD ARTICLE', 'STATUS: SKIPPED', 'DATA:',r['Source'], r['pubmed'])
                pass
            else:
                try:
                    article = Article.objects.create(
                        pmid=int(r['pubmed']), 
                        title=r['Title'], 
                        journal= Journal.objects.get(medabbr=r['Source']), 
                        abstract=r['abstract'],
                        pubdate=(fix_date(r['PubDate'])), 
                        upvotes=0, 
                        downvotes=0)
                    article.save()  
                    print ('JOB: ADD ARTICLE', 'STATUS: SUCCESS', 'DATA:',r['Source'], r['pubmed'])

                except:
                    print ('JOB: ADD ARTICLE', 'STATUS: FAILED', 'DATA:',r['Source'], r['pubmed'])
                    print (Journal.objects.get(name=r['Source']))
                    print (int(r['pubmed']))
                pass

    # art = Settings.objects.all()
    # b = art.bookmarks.all().count()


    content = {
        'page_title': 'Managment Dashboard',
        'all_journals_subscription': journal_subscritions_all,
        'app_name': app_name,
        'journal_count': Journal.objects.filter(radiology=True).count(),
        'article_count': Article.objects.all().count(),
        'user_count': User.objects.all().count(),
        'subscrption_count': len(journal_subscritions_all)

        # 'b':b
    }  
   
    return render(request, templates['dashboard'], content)

